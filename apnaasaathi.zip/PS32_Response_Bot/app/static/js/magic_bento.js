/**
 * Magic Bento Grid - Vanilla JS Port
 * Handles Spotlight, Particles, Magnetism, and Tilt effects using GSAP
 */

document.addEventListener('DOMContentLoaded', () => {
    // Configuration
    const CONFIG = {
        particleCount: 12,
        spotlightRadius: 300,
        glowColor: '0, 210, 255', // Cyan
        mobileBreakpoint: 768
    };

    const isMobile = window.innerWidth <= CONFIG.mobileBreakpoint;

    // --- Spotlight Logic ---
    const grid = document.querySelector('.bento-grid');
    if (grid && !isMobile) {
        // Create Spotlight Element
        const spotlight = document.createElement('div');
        spotlight.className = 'global-spotlight';
        document.body.appendChild(spotlight);

        const cards = grid.querySelectorAll('.bento-card');

        document.addEventListener('mousemove', (e) => {
            const gridRect = grid.getBoundingClientRect();
            // Check if mouse is near grid
            if (e.clientX < gridRect.left - 100 || e.clientX > gridRect.right + 100 ||
                e.clientY < gridRect.top - 100 || e.clientY > gridRect.bottom + 100) {
                gsap.to(spotlight, { opacity: 0, duration: 0.3 });
                return;
            }

            // Move spotlight
            gsap.to(spotlight, {
                left: e.clientX,
                top: e.clientY,
                opacity: 0.6,
                duration: 0.1,
                ease: 'power2.out'
            });

            // Calculate individualized card glow
            cards.forEach(card => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;

                card.style.setProperty('--glow-x', `${x}px`);
                card.style.setProperty('--glow-y', `${y}px`);
            });
        });
    }

    // --- Particle & Tilt Logic (Per Card) ---
    const cards = document.querySelectorAll('.bento-card');

    cards.forEach(card => {
        if (isMobile) return;

        // Magnetism & Tilt
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            // Tilt
            const rotateX = ((y - centerY) / centerY) * -10;
            const rotateY = ((x - centerX) / centerX) * 10;

            gsap.to(card, {
                rotateX: rotateX,
                rotateY: rotateY,
                duration: 0.1,
                ease: 'power2.out',
                transformPerspective: 1000
            });
        });

        card.addEventListener('mouseleave', () => {
            gsap.to(card, {
                rotateX: 0,
                rotateY: 0,
                x: 0,
                y: 0,
                duration: 0.5,
                ease: 'elastic.out(1, 0.5)'
            });

            // Clear Particles
            const particles = card.querySelectorAll('.particle');
            particles.forEach(p => p.remove());
        });

        // Mouse Enter - Spawn Particles
        card.addEventListener('mouseenter', () => {
            spawnParticles(card);
        });

        // Click Ripple Effect
        card.addEventListener('click', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const ripple = document.createElement('div');
            ripple.className = 'ripple-effect';
            ripple.style.left = `${x}px`;
            ripple.style.top = `${y}px`;
            card.appendChild(ripple);

            gsap.fromTo(ripple,
                { scale: 0, opacity: 1 },
                { scale: 4, opacity: 0, duration: 1, ease: 'power2.out', onComplete: () => ripple.remove() }
            );
        });
    });

    function spawnParticles(card) {
        const { width, height } = card.getBoundingClientRect();

        for (let i = 0; i < CONFIG.particleCount; i++) {
            const p = document.createElement('div');
            p.className = 'particle';
            p.style.left = Math.random() * width + 'px';
            p.style.top = Math.random() * height + 'px';
            p.style.background = `rgba(${CONFIG.glowColor}, 1)`;
            p.style.boxShadow = `0 0 6px rgba(${CONFIG.glowColor}, 0.6)`;
            card.appendChild(p);

            // Animate
            const duration = 2 + Math.random() * 2;

            gsap.fromTo(p,
                { scale: 0, opacity: 0 },
                { scale: 1, opacity: 1, duration: 0.3 }
            );

            gsap.to(p, {
                x: (Math.random() - 0.5) * 100,
                y: (Math.random() - 0.5) * 100,
                rotation: Math.random() * 360,
                duration: duration,
                repeat: -1,
                yoyo: true,
                ease: 'none'
            });

            gsap.to(p, {
                opacity: 0.4,
                duration: duration / 2,
                repeat: -1,
                yoyo: true
            });
        }
    }
});
