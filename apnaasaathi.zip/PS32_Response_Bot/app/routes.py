from flask import render_template, request, jsonify, current_app, redirect, url_for
from . import db
from .models import Course, FAQ, ChatLog
from .ai_engine import get_ai_response

# Access app instance indirectly via current_app context in routes, 
# but easiest way in this pattern is to use current_app or Blueprints. 
# For simplicity in this structure we'll use current_app.add_url_rule or specific routing.
# However, to avoid circular imports, let's use current_app context.
# Or better, we can define a blueprint or just import app if we weren't using a factory.
# Let's use the simple `current_app` pattern by importing `app` 
# actually, in the __init__.py we imported routes. So routes must define the routes on `current_app`. 
# BUT `current_app` is a proxy. A common pattern is using a Blueprint.

from flask import Blueprint

main_bp = Blueprint('main', __name__)

@main_bp.route('/favicon.ico')
def favicon():
    return current_app.send_static_file('assets/favicon.ico')

@main_bp.route('/')
def home():
    return render_template('home.html')

@main_bp.route('/chat')
def chat_page():
    return render_template('chat.html')

@main_bp.route('/courses')
def courses():
    all_courses = Course.query.all()
    return render_template('courses.html', courses=all_courses)

@main_bp.route('/fees')
def fees():
    all_courses = Course.query.all()
    # Logic to sort or filter if needed
    return render_template('fees.html', courses=all_courses)

@main_bp.route('/admin')
def admin():
    courses = Course.query.all()
    faqs = FAQ.query.all()
    logs = ChatLog.query.order_by(ChatLog.timestamp.desc()).limit(10).all()
    return render_template('admin.html', courses=courses, faqs=faqs, logs=logs)

# --- API Endpoints ---

@main_bp.route('/api/chat', methods=['POST'])
def api_chat():
    data = request.json
    user_msg = data.get('message', '')
    
    if not user_msg:
        return jsonify({'response': 'Please say something.'})
        
    # Get AI Response
    bot_reply = get_ai_response(user_msg)
    
    # Save Log
    log = ChatLog(user_message=user_msg, bot_response=bot_reply)
    db.session.add(log)
    db.session.commit()
    
    return jsonify({'response': bot_reply})

@main_bp.route('/api/add_course', methods=['POST'])
def add_course():
    data = request.form
    new_course = Course(
        title=data['title'],
        duration=data.get('duration'),
        fees=data.get('fees'),
        description=data.get('description'),
        eligibility=data.get('eligibility')
    )
    db.session.add(new_course)
    db.session.commit()
    return redirect(url_for('main.admin'))
